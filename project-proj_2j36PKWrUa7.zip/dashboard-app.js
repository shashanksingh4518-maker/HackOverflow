// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-black"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function DashboardApp() {
    const [user, setUser] = React.useState(null);
    const [currentView, setCurrentView] = React.useState('overview');
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        const sessionUser = Storage.getSession();
        if (!sessionUser) {
            window.location.href = 'index.html';
        } else {
            setUser(sessionUser);
            setLoading(false);
        }
    }, []);

    const handleLogout = () => {
        Storage.clearSession();
    };

    if (loading) return null;

    const renderContent = () => {
        switch(currentView) {
            case 'overview': return <Overview userRole={user.role} />;
            case 'events': return <EventsManager userRole={user.role} />;
            case 'resources': return <ResourcesManager userRole={user.role} />;
            default: return <div className="flex items-center justify-center h-full text-gray-400">Module under construction</div>;
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex">
            <Sidebar 
                currentView={currentView} 
                onChangeView={setCurrentView}
                userRole={user.role}
            />
            
            <div className="flex-1 ml-[var(--sidebar-width)] flex flex-col min-h-screen transition-all duration-300">
                <Header user={user} onLogout={handleLogout} />
                
                <main className="flex-1 p-6 lg:p-8">
                    {renderContent()}
                </main>
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <DashboardApp />
  </ErrorBoundary>
);