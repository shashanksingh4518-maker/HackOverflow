function LoginForm() {
    const [email, setEmail] = React.useState('admin@campus.edu');
    const [password, setPassword] = React.useState('password');
    const [loading, setLoading] = React.useState(false);
    const [error, setError] = React.useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            await AuthService.login(email, password);
            window.location.href = 'dashboard.html';
        } catch (err) {
            setError('Invalid email or password. Try "password".');
            setLoading(false);
        }
    };

    return (
        <div className="w-full max-w-md mx-auto">
            <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100">
                <div className="mb-8 text-center">
                    <h2 className="text-2xl font-bold text-gray-900">Welcome Back</h2>
                    <p className="text-gray-500 mt-2">Sign in to access your campus portal</p>
                </div>

                {error && (
                    <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-lg flex items-center gap-3 text-red-700">
                        <div className="icon-circle-alert text-lg"></div>
                        <p className="text-sm">{error}</p>
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                        <div className="relative">
                            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 icon-mail"></div>
                            <input 
                                type="email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="input-field pl-10"
                                placeholder="student@university.edu"
                                required
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                        <div className="relative">
                            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 icon-lock"></div>
                            <input 
                                type="password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="input-field pl-10"
                                placeholder="••••••••"
                                required
                            />
                        </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                        <label className="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                            <span className="text-gray-600">Remember me</span>
                        </label>
                        <a href="#" className="text-blue-600 hover:text-blue-700 font-medium">Forgot password?</a>
                    </div>

                    <button 
                        type="submit" 
                        disabled={loading}
                        className="btn btn-primary w-full py-3 text-lg"
                    >
                        {loading ? (
                            <>
                                <div className="icon-loader animate-spin"></div>
                                Signing in...
                            </>
                        ) : (
                            <>
                                Sign In
                                <div className="icon-arrow-right"></div>
                            </>
                        )}
                    </button>
                </form>

                <div className="mt-6 pt-6 border-t border-gray-100">
                    <div className="text-sm text-center text-gray-500 mb-4">Demo Accounts:</div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                        <button onClick={() => setEmail('admin@campus.edu')} className="px-2 py-1 bg-gray-50 hover:bg-gray-100 rounded border border-gray-200">Admin</button>
                        <button onClick={() => setEmail('org@campus.edu')} className="px-2 py-1 bg-gray-50 hover:bg-gray-100 rounded border border-gray-200">Organizer</button>
                        <button onClick={() => setEmail('student@campus.edu')} className="px-2 py-1 bg-gray-50 hover:bg-gray-100 rounded border border-gray-200">Student</button>
                    </div>
                </div>
            </div>
        </div>
    );
}