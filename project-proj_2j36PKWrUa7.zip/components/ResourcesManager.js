function ResourcesManager({ userRole }) {
    const resources = [
        { id: 1, name: 'Seminar Hall A', type: 'Hall', capacity: 200, status: 'available', image: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&q=80&w=400' },
        { id: 2, name: 'Computer Lab 3', type: 'Lab', capacity: 40, status: 'booked', image: 'https://images.unsplash.com/photo-1596496181871-9681eacf9764?auto=format&fit=crop&q=80&w=400' },
        { id: 3, name: 'Projector Kit #1', type: 'Equipment', capacity: 'N/A', status: 'available', image: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=400' },
        { id: 4, name: 'Conference Room', type: 'Room', capacity: 15, status: 'maintenance', image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=400' },
    ];

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div>
                <h1 className="text-2xl font-bold text-gray-900">Campus Resources</h1>
                <p className="text-gray-500">Book rooms, labs, and equipment for your events.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {resources.map((resource) => (
                    <div key={resource.id} className="card p-0 overflow-hidden group hover:shadow-md transition-shadow">
                        <div className="h-40 bg-gray-100 relative overflow-hidden">
                            <img src={resource.image} alt={resource.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            <div className="absolute top-3 right-3">
                                <span className={`px-2 py-1 rounded-md text-xs font-bold uppercase tracking-wide backdrop-blur-md ${
                                    resource.status === 'available' ? 'bg-green-500/90 text-white' : 
                                    resource.status === 'booked' ? 'bg-blue-500/90 text-white' : 'bg-gray-500/90 text-white'
                                }`}>
                                    {resource.status}
                                </span>
                            </div>
                        </div>
                        <div className="p-5">
                            <h3 className="font-bold text-gray-900 mb-1">{resource.name}</h3>
                            <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                                <span className="flex items-center gap-1">
                                    <Icon name="layers" size="text-xs" /> {resource.type}
                                </span>
                                <span className="flex items-center gap-1">
                                    <Icon name="users" size="text-xs" /> {resource.capacity}
                                </span>
                            </div>
                            <button 
                                disabled={resource.status !== 'available'}
                                className="w-full btn border border-gray-200 hover:bg-blue-600 hover:text-white hover:border-transparent disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                            >
                                {resource.status === 'available' ? 'Book Now' : 'Unavailable'}
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}