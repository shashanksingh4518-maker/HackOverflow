function Header({ user, onLogout }) {
    const [showMenu, setShowMenu] = React.useState(false);

    return (
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 sticky top-0 z-20">
            {/* Left: Breadcrumbs or Page Title (Placeholder) */}
            <div className="flex items-center gap-4">
                <div className="relative">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                        <Icon name="search" size="text-lg" />
                    </div>
                    <input 
                        type="text" 
                        placeholder="Search events, resources..." 
                        className="pl-10 pr-4 py-2 bg-gray-50 border-none rounded-lg text-sm focus:ring-2 focus:ring-blue-100 w-64 transition-all"
                    />
                </div>
            </div>

            {/* Right: Actions & Profile */}
            <div className="flex items-center gap-4">
                <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center relative text-gray-500 hover:text-gray-700">
                    <Icon name="bell" />
                    <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
                
                <div className="relative">
                    <button 
                        onClick={() => setShowMenu(!showMenu)}
                        className="flex items-center gap-3 pl-2 pr-1 py-1 rounded-full hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-all"
                    >
                        <div className="text-right hidden md:block">
                            <div className="text-sm font-semibold text-gray-900 leading-tight">{user?.name}</div>
                            <div className="text-xs text-gray-500 capitalize">{user?.role}</div>
                        </div>
                        <img 
                            src={user?.avatar || "https://ui-avatars.com/api/?name=User&background=random"} 
                            alt="Profile" 
                            className="w-9 h-9 rounded-full object-cover border border-gray-200"
                        />
                        <Icon name="chevron-down" size="text-xs" className="text-gray-400 mr-2" />
                    </button>

                    {showMenu && (
                        <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-100 py-1 animate-in fade-in slide-in-from-top-2">
                            <a href="#profile" className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                                <Icon name="user" size="text-sm" /> Profile
                            </a>
                            <a href="#settings" className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                                <Icon name="settings" size="text-sm" /> Settings
                            </a>
                            <div className="h-px bg-gray-100 my-1"></div>
                            <button 
                                onClick={onLogout}
                                className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                            >
                                <Icon name="log-out" size="text-sm" /> Sign Out
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
}