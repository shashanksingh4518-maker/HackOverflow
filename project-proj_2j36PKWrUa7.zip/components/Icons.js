function Icon({ name, size = "text-xl", className = "" }) {
    // Ensures usage of lucide static icons with correct class pattern
    return <div className={`icon-${name} ${size} ${className}`}></div>;
}