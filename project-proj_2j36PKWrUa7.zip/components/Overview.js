function Overview({ userRole }) {
    const canvasRef = React.useRef(null);

    React.useEffect(() => {
        if (!canvasRef.current) return;
        
        const ctx = canvasRef.current.getContext('2d');
        // Destroy existing chart if any (simple check)
        const existingChart = ChartJS.getChart(canvasRef.current);
        if (existingChart) existingChart.destroy();

        new ChartJS(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Event Participations',
                    data: [12, 19, 3, 5, 2, 3, 20],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true, grid: { color: '#f3f4f6' } },
                    x: { grid: { display: false } }
                }
            }
        });
    }, []);

    const StatCard = ({ title, value, change, icon, color }) => (
        <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
                    <Icon name={icon} className="text-white text-xl" />
                </div>
                <span className={`text-xs font-semibold px-2 py-1 rounded-full ${change >= 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {change > 0 ? '+' : ''}{change}%
                </span>
            </div>
            <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
            <div className="text-2xl font-bold text-gray-900 mt-1">{value}</div>
        </div>
    );

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div>
                <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
                <p className="text-gray-500">Welcome back! Here's what's happening on campus today.</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Total Events" value="24" change={12} icon="calendar-days" color="bg-blue-500" />
                <StatCard title="Active Clubs" value="18" change={5} icon="users" color="bg-purple-500" />
                <StatCard title="Resources Booked" value="8" change={-2} icon="box" color="bg-orange-500" />
                <StatCard title="New Members" value="156" change={24} icon="user-plus" color="bg-green-500" />
            </div>

            {/* Main Content Split */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left: Chart */}
                <div className="lg:col-span-2 card">
                    <div className="flex items-center justify-between mb-6">
                        <h3 className="font-bold text-gray-900">Activity Trends</h3>
                        <select className="text-sm border-gray-200 rounded-lg text-gray-500">
                            <option>This Week</option>
                            <option>Last Week</option>
                        </select>
                    </div>
                    <div className="h-64">
                        <canvas ref={canvasRef}></canvas>
                    </div>
                </div>

                {/* Right: Recent Activity */}
                <div className="card">
                    <h3 className="font-bold text-gray-900 mb-4">Recent Activities</h3>
                    <div className="space-y-4">
                        {[1, 2, 3, 4].map((i) => (
                            <div key={i} className="flex gap-3 items-start">
                                <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center flex-shrink-0">
                                    <Icon name="bell" size="text-xs" className="text-blue-600" />
                                </div>
                                <div>
                                    <p className="text-sm text-gray-900 font-medium">Photography Club Event Approved</p>
                                    <p className="text-xs text-gray-500">2 hours ago</p>
                                </div>
                            </div>
                        ))}
                    </div>
                    <button className="w-full mt-4 text-sm text-blue-600 font-medium hover:text-blue-700">View All Activity</button>
                </div>
            </div>
        </div>
    );
}