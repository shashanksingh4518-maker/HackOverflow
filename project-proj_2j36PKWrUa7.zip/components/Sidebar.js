function Sidebar({ currentView, onChangeView, userRole }) {
    const menuItems = [
        { id: 'overview', label: 'Overview', icon: 'layout-dashboard' },
        { id: 'events', label: 'Events', icon: 'calendar-days' },
        { id: 'resources', label: 'Resources', icon: 'box' },
        { id: 'clubs', label: 'Clubs', icon: 'users' },
    ];

    // Admin specific items
    if (userRole === 'admin') {
        menuItems.push({ id: 'settings', label: 'Settings', icon: 'settings' });
    }

    return (
        <aside className="fixed left-0 top-0 h-full bg-white border-r border-gray-200 flex flex-col z-30 transition-all duration-300 w-[var(--sidebar-width)]">
            <div className="h-16 flex items-center px-6 border-b border-gray-100">
                <Logo className="text-lg" />
            </div>

            <div className="flex-1 overflow-y-auto py-6 px-4 space-y-1">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4 px-2">Main Menu</div>
                {menuItems.map((item) => (
                    <div 
                        key={item.id}
                        onClick={() => onChangeView(item.id)}
                        className={`nav-item group ${currentView === item.id ? 'active' : ''}`}
                    >
                        <Icon name={item.icon} className={currentView === item.id ? 'text-white' : 'text-gray-400 group-hover:text-blue-600'} />
                        <span className="font-medium">{item.label}</span>
                        {item.id === 'events' && <span className="ml-auto bg-blue-100 text-blue-700 py-0.5 px-2 rounded-full text-xs">3</span>}
                    </div>
                ))}
            </div>

            <div className="p-4 border-t border-gray-100">
                <div className="bg-blue-50 rounded-xl p-4">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <Icon name="life-buoy" size="text-sm" className="text-blue-600" />
                        </div>
                        <div className="font-semibold text-sm text-blue-900">Need Help?</div>
                    </div>
                    <p className="text-xs text-blue-700 mb-3">Check our documentation or contact support.</p>
                    <button className="w-full py-1.5 bg-blue-600 text-white text-xs font-medium rounded-lg hover:bg-blue-700 transition-colors">
                        Contact Support
                    </button>
                </div>
            </div>
        </aside>
    );
}