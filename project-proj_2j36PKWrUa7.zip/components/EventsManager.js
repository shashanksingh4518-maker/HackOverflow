function EventsManager({ userRole }) {
    const [filter, setFilter] = React.useState('all');

    const events = [
        { id: 1, title: 'Annual Tech Symposium', club: 'Computer Science Club', date: '2026-02-15', status: 'approved', attendees: 120 },
        { id: 2, title: 'Photography Workshop', club: 'Shutterbugs', date: '2026-02-18', status: 'pending', attendees: 45 },
        { id: 3, title: 'Charity Run', club: 'NSS Unit', date: '2026-02-20', status: 'upcoming', attendees: 200 },
        { id: 4, title: 'Debate Championship', club: 'Debate Society', date: '2026-02-22', status: 'rejected', attendees: 0 },
    ];

    const getStatusColor = (status) => {
        switch(status) {
            case 'approved': return 'bg-green-100 text-green-700 border-green-200';
            case 'pending': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
            case 'rejected': return 'bg-red-100 text-red-700 border-red-200';
            default: return 'bg-blue-100 text-blue-700 border-blue-200';
        }
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Events</h1>
                    <p className="text-gray-500">Manage and track campus events.</p>
                </div>
                {(userRole === 'organizer' || userRole === 'admin') && (
                    <button className="btn btn-primary">
                        <Icon name="plus" /> Create Event
                    </button>
                )}
            </div>

            {/* Filters */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
                {['all', 'approved', 'pending', 'upcoming'].map(f => (
                    <button 
                        key={f}
                        onClick={() => setFilter(f)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium capitalize whitespace-nowrap transition-colors ${filter === f ? 'bg-gray-900 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'}`}
                    >
                        {f} Events
                    </button>
                ))}
            </div>

            {/* Events List */}
            <div className="card overflow-hidden p-0">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 border-b border-gray-100 text-xs uppercase text-gray-500 font-semibold">
                            <tr>
                                <th className="px-6 py-4">Event Name</th>
                                <th className="px-6 py-4">Organized By</th>
                                <th className="px-6 py-4">Date</th>
                                <th className="px-6 py-4">Status</th>
                                <th className="px-6 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {events.map((event) => (
                                <tr key={event.id} className="hover:bg-gray-50 transition-colors">
                                    <td className="px-6 py-4">
                                        <div className="font-medium text-gray-900">{event.title}</div>
                                        <div className="text-xs text-gray-500">{event.attendees} Registered</div>
                                    </td>
                                    <td className="px-6 py-4 text-sm text-gray-600">{event.club}</td>
                                    <td className="px-6 py-4 text-sm text-gray-600">{event.date}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(event.status)} capitalize`}>
                                            {event.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex items-center justify-end gap-2">
                                            <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-blue-600 transition-colors">
                                                <Icon name="eye" size="text-sm" />
                                            </button>
                                            {userRole === 'admin' && (
                                                <>
                                                    <button className="p-2 hover:bg-green-50 rounded-lg text-gray-500 hover:text-green-600 transition-colors" title="Approve">
                                                        <Icon name="check" size="text-sm" />
                                                    </button>
                                                    <button className="p-2 hover:bg-red-50 rounded-lg text-gray-500 hover:text-red-600 transition-colors" title="Reject">
                                                        <Icon name="x" size="text-sm" />
                                                    </button>
                                                </>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}