function Logo({ className = "" }) {
    return (
        <div className={`flex items-center gap-2 font-bold text-2xl text-blue-600 ${className}`}>
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                <div className="icon-graduation-cap text-2xl"></div>
            </div>
            <span>CampusHub</span>
        </div>
    );
}