// Simple utility to manage local session state
const Storage = {
    set: (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.error('Error saving to storage', e);
        }
    },
    get: (key) => {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : null;
        } catch (e) {
            console.error('Error reading from storage', e);
            return null;
        }
    },
    remove: (key) => {
        localStorage.removeItem(key);
    },
    // Mock user session management
    saveSession: (user) => {
        localStorage.setItem('campus_hub_user', JSON.stringify(user));
    },
    getSession: () => {
        const user = localStorage.getItem('campus_hub_user');
        return user ? JSON.parse(user) : null;
    },
    clearSession: () => {
        localStorage.removeItem('campus_hub_user');
        window.location.href = 'index.html';
    }
};

// Mock Auth Service
const AuthService = {
    login: async (email, password) => {
        // In a real app, this would check against the DB
        // For now, we simulate success with different roles based on email pattern
        
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (password === 'password') {
                    let role = 'participant';
                    let name = 'Student User';
                    
                    if (email.includes('admin')) {
                        role = 'admin';
                        name = 'Campus Administrator';
                    } else if (email.includes('org')) {
                        role = 'organizer';
                        name = 'Event Organizer';
                    }

                    const user = {
                        id: 'usr_' + Math.random().toString(36).substr(2, 9),
                        email,
                        name,
                        role,
                        department: 'Computer Science',
                        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
                    };
                    
                    Storage.saveSession(user);
                    resolve(user);
                } else {
                    reject(new Error('Invalid credentials'));
                }
            }, 800);
        });
    }
};