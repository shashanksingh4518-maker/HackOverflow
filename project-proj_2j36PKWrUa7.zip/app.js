// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-black"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col" data-name="landing-page">
        {/* Navigation */}
        <nav className="w-full bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
                <Logo />
                <div className="hidden md:flex items-center gap-8">
                    <a href="#features" className="text-gray-600 hover:text-blue-600 font-medium">Features</a>
                    <a href="#about" className="text-gray-600 hover:text-blue-600 font-medium">About</a>
                    <a href="#contact" className="text-gray-600 hover:text-blue-600 font-medium">Contact</a>
                </div>
            </div>
        </nav>

        {/* Hero Section */}
        <main className="flex-grow flex items-center justify-center relative overflow-hidden px-4 py-20">
            <div className="absolute top-0 left-0 w-full h-full -z-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-100 via-gray-50 to-white"></div>
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
            <div className="absolute top-0 left-0 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>

            <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
                <div className="space-y-8">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-sm font-medium">
                        <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></div>
                        New Academic Year Ready
                    </div>
                    <h1 className="text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight leading-[1.1]">
                        Manage Your Campus <br/>
                        <span className="text-blue-600">Like a Pro</span>
                    </h1>
                    <p className="text-xl text-gray-600 max-w-lg leading-relaxed">
                        The all-in-one platform for university events, club management, and resource booking. Simplify campus life today.
                    </p>
                    
                    <div className="grid grid-cols-2 gap-6 pt-4">
                        <div className="flex flex-col gap-2">
                            <div className="icon-calendar-days text-blue-600 text-2xl mb-1"></div>
                            <h3 className="font-bold text-gray-900">Event Planning</h3>
                            <p className="text-sm text-gray-500">Streamline approvals and scheduling.</p>
                        </div>
                        <div className="flex flex-col gap-2">
                            <div className="icon-users text-blue-600 text-2xl mb-1"></div>
                            <h3 className="font-bold text-gray-900">Club Management</h3>
                            <p className="text-sm text-gray-500">Coordinate members and activities.</p>
                        </div>
                    </div>
                </div>

                <div className="relative">
                    <LoginForm />
                </div>
            </div>
        </main>

        <footer className="bg-white border-t border-gray-100 py-12">
            <div className="max-w-7xl mx-auto px-4 text-center text-gray-500">
                <p>&copy; 2026 CampusHub Systems. All rights reserved.</p>
            </div>
        </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <LandingPage />
  </ErrorBoundary>
);