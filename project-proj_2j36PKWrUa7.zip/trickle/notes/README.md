# CampusHub - Unified Campus Resource & Event Management System

## Overview
CampusHub is a comprehensive web application designed to replace fragmented campus management tools. It offers a single, scalable platform for managing events, clubs, and shared resources with dedicated portals for Admins, Organizers, and Participants.

## Architecture
- **Frontend**: React 18 (CDN), TailwindCSS
- **Database**: Trickle Database (Serverless)
- **Authentication**: Custom implementation using Trickle DB
- **Design**: Modern Campus Theme

## Features
- **Role-Based Access**: Admin, Organizer, Participant views
- **Event Management**: Create, approve, and track events
- **Resource Booking**: Manage campus facilities
- **Analytics**: Visualization of campus activities

## Maintenance Rules
- Update this README when adding new major modules.
- Ensure all public assets are logged in `trickle/assets`.